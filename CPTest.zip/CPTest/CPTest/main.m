//
//  main.m
//  CPTest
//
//  Created by msi on 2023/7/20.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
