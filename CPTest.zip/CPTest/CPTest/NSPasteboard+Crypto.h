//
//  NSPasteboard+Crypto.h
//  CPTest
//
//  Created by lyf on 2023/8/11.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSPasteboard (Crypto)

@end

NS_ASSUME_NONNULL_END
