//
//  ViewController.h
//  CPTest
//
//  Created by msi on 2023/7/20.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

